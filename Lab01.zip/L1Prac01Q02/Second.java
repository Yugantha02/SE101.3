public class Second
{
	public static void main(String[] args)
		{
			System.out.println("Tharindi Dinesha");
			System.out.println("Software Engineering");
		}
}
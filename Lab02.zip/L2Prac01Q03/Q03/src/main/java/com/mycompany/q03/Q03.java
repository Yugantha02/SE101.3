
package com.mycompany.q03;

public class Q03 
{

    public static void main(String[] args) 
    {
        //For Loop--------------------
     /*  int i;
       for(i=0; i<5; i++)
       {
           System.out.println("Executing Loop "+i);
       }  */
        
        
        //While Loop-------------------------
        int i=0;
        while(i<5)
        {
            System.out.println("Executiong Loop "+i);
            i++;
        }
    }
}

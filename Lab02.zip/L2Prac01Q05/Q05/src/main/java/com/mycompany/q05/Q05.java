
package com.mycompany.q05;
import java.util.Scanner;
public class Q05 
{

    public static void main(String[] args) 
    {
      /* 	char grade ='A';
	 switch(grade)
	{
	case 'A' :
	System.out.println("Excellent!"); 
	break;
	case 'D' :
	System.out.println("You passed");
	case 'F' :
	System.out.println("Better try again");
	break;
	default :
	System.out.println("Invalid grade");
	}
	System.out.println("Your grade is " + grade);  */
        
        
        //Removing break----------------------
      /*  char grade ='A';
	 switch(grade)
	{
	case 'A' :
	System.out.println("Excellent!"); 
	
	case 'D' :
	System.out.println("You passed");
	case 'F' :
	System.out.println("Better try again");
	break;
	default :
	System.out.println("Invalid grade");
	}
	System.out.println("Your grade is " + grade); */
        
        
     /* Scanner sc=new Scanner(System.in);
        System.out.println("Enter Grade ");
        String grade=sc.nextLine();  */
       
        //With If else if--------------------
     /*   char grade='A';
        if(grade=='A')
        {
            System.out.println("Excellent");
            System.out.println("Your grade is "+grade);
        }
        else if(grade=='B')
        {
            System.out.println("You Passed");
            System.out.println("Your grade is "+grade);
        }
        else if(grade=='D')
        {
            System.out.println("Better try again");
            System.out.println("Your grade is "+grade);
        }
        else
        {
            System.out.println("Invalid grade");
            System.out.println("Your grade is "+grade);
        }  
        */
        
            
        
            

    }
}

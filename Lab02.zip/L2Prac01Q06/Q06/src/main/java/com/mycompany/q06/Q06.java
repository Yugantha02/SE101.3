
package com.mycompany.q06;

public class Q06 
{

    public static void main(String[] args) 
    
        {
     	 int [] numbers = {10, 20, 30, 40, 50};
      		for(int x : numbers )
               // for(int x; x<5; x++)
                {                   
                       System.out.print( x );
                       System.out.print("\n");  //** 		
      		}
	 
         
      	String [] names ={"James", "Larry", "Tom", "Lacy"}; //**
      		for( String name : names ) 
                {
        		 	System.out.print( name );
         			System.out.print(",");
                } //**

    }
}

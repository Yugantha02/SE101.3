
package com.mycompany.prac04q03;

public class Lecturer extends Person
{
    private String programme;
    
    public void setProgramme(String programme)
    {
        this.programme=programme;
    }
    public String getProgram()
    {
        return programme;
    }
}


package com.mycompany.prac04q03;

public class Student extends Person
{
    private String course;
    
    public void setCourse(String course)
    {
        this.course=course;
    }
    public String getCourse()
    {
        return course;
    }
}

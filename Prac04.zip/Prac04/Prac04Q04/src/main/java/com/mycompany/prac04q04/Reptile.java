
package com.mycompany.prac04q04;

public class Reptile extends Animal
{
    
}

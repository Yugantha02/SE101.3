
package com.mycompany.labquestion02;

 public interface Shape
{
    abstract double CalculateArea();
    abstract double CalculatePerimeter();
}

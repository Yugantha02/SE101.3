
package com.mycompany.prac05ex02;

public class Politician implements Speaker 
{
    public void speak()
    {
        System.out.println("Hello, I am a Politician");
    }
}

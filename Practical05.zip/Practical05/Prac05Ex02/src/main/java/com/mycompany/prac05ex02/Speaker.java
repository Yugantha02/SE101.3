
package com.mycompany.prac05ex02;

public interface Speaker 
{
    public void speak();
}

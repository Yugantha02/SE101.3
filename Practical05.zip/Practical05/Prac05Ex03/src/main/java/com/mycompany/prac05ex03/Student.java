
package com.mycompany.prac05ex03;

public class Student
{
    final int marks = 100;
    //can not override "final" methods
    
    
    //final void display();
    final void display()
    {
        System.out.println("...");
    } 

}

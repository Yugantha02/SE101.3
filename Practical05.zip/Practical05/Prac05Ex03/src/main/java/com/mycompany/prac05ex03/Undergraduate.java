
package com.mycompany.prac05ex03;

public class Undergraduate extends Student
{
    //can not inherite from final class. This can not have child class.
    //if class is final, we can not create child class
    //if final method, can not override
    //if final method, can not change
    //final classes, can not have sub classes
    //final variables can not have a value other than the one assigned at initialization assigned to it

}

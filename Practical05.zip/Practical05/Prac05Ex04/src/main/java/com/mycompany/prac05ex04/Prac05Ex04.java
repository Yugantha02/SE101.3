
package com.mycompany.prac05ex04;

public class Prac05Ex04 
{

    public static void main(String[] args)
    {
        Circle c1=new Circle(10);
        c1.display();
        
        Rectangle r1=new Rectangle(10,20);
        r1.display();
      
        
    }
}
